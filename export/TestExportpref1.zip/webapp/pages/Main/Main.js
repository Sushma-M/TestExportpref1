Application.$controller("TestExportpref1Controller", ["$scope", "Widgets", "Variables", function ($scope, Widgets, Variables) {
	"use strict";

}]);