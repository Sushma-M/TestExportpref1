File you need to know:
  * app.css:  application CSS
  * index.html and login.html:  can be edited directly to customize, such as including meta, script and other tags.
  * app.js : contains any application owned component definitions and functions.
  * app.variables.json : contains any application variable definition.
  * config.json : contains configuration of the prefab